exports.generateAI = (req, res) => {
  res.send("AI Backend Working");
};