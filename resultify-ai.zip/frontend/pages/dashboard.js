import ChatBox from "../components/ChatBox";
export default function Dashboard() {
  return <ChatBox />;
}