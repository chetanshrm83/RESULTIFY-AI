export default function Home() {
  return <h1>Resultify AI 🚀</h1>;
}