import { useState } from "react";

export default function ChatBox() {
  const [input, setInput] = useState("");
  const [response, setResponse] = useState("");

  const send = async () => {
    setResponse("AI response will appear here");
  };

  return (
    <div>
      <textarea onChange={(e) => setInput(e.target.value)} />
      <button onClick={send}>Send</button>
      <p>{response}</p>
    </div>
  );
}